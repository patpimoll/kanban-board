import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import authRoutes from "./routes/AuthRoutes";
import boardRoutes from "./routes/BoardRoutes";
import columnRoutes from "./routes/ColumnRoutes";
import taskRoutes from "./routes/TaskRoutes";

const app = express();

app.use(cors());
app.use(bodyParser.json());

app.use("/api/auth", authRoutes);
app.use("/api/boards", boardRoutes);
app.use("/api/columns", columnRoutes);
app.use("/api/tasks", taskRoutes);

export default app;
