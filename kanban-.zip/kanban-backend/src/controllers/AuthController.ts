import { Request, Response } from "express";
import { AppDataSource } from "../database";
import { User } from "../entities/User";
import * as bcrypt from "bcrypt";
import * as jwt from "jsonwebtoken";

export class AuthController {
  // การลงทะเบียน
  static async register(req: Request, res: Response): Promise<void> {
    const { email, password } = req.body;
    try {
      const userRepository = AppDataSource.getRepository(User);
      const existingUser = await userRepository.findOneBy({ email });
      if (existingUser) {
        res.status(400).json({ message: "User already exists" });
        return;
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const user = userRepository.create({ email, password: hashedPassword });
      await userRepository.save(user);

      res.status(201).json({ message: "User registered successfully" });
    } catch (error) {
      res.status(500).json({ error: error.message || "An unexpected error occurred" });
    }
  }

  // การเข้าสู่ระบบ
  static async login(req: Request, res: Response): Promise<void> {
    const { email, password } = req.body;
    try {
      const userRepository = AppDataSource.getRepository(User);
      const user = await userRepository.findOneBy({ email });
      if (!user || !(await bcrypt.compare(password, user.password))) {
        res.status(401).json({ message: "Invalid credentials" });
        return;
      }

      const token = jwt.sign({ userId: user.id }, "your_secret_key", { expiresIn: "1h" });
      res.status(200).json({ token });
    } catch (error) {
      res.status(500).json({ error: error.message || "An unexpected error occurred" });
    }
  }
}
