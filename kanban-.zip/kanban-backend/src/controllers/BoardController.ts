import { Request, Response } from "express";
import { AppDataSource } from "../database";
import { Board } from "../entities/Board";
import { User } from "../entities/User";
import { Column } from "../entities/Column";

export class BoardController {
  static async createBoard(req: Request, res: Response) {
    const { name } = req.body;
    const userId = req.userId;  

    try {
      const boardRepository = AppDataSource.getRepository(Board);
      const userRepository = AppDataSource.getRepository(User);

      const user = await userRepository.findOneBy({ id: userId });
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const board = new Board();
      board.name = name;
      board.user = user;
      await boardRepository.save(board);

      res.status(201).json({ message: "Board created successfully", board });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async getBoards(req: Request, res: Response) {
    const userId = req.userId;  

    try {
      const boardRepository = AppDataSource.getRepository(Board);
      const boards = await boardRepository.find({ where: { user: { id: userId } }, relations: ["columns"] });
      res.status(200).json(boards);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}
