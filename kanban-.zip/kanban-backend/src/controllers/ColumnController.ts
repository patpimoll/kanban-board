import { Request, Response } from "express";
import { AppDataSource } from "../database";
import { Column } from "../entities/Column";
import { Board } from "../entities/Board";

export class ColumnController {
  static async createColumn(req: Request, res: Response) {
    const { name, boardId } = req.body;

    try {
      const columnRepository = AppDataSource.getRepository(Column);
      const boardRepository = AppDataSource.getRepository(Board);
      const board = await boardRepository.findOneBy({ id: boardId });

      if (!board) {
        return res.status(404).json({ message: "Board not found" });
      }

      const column = new Column();
      column.name = name;
      column.board = board;
      await columnRepository.save(column);

      res.status(201).json({ message: "Column created successfully", column });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async getColumns(req: Request, res: Response) {
    const boardId = req.params.boardId;
    try {
      const columnRepository = AppDataSource.getRepository(Column);
      const columns = await columnRepository.find({ where: { board: { id: boardId } }, relations: ["tasks"] });
      res.status(200).json(columns);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}
