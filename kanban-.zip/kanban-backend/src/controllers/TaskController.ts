import { Request, Response } from "express";
import { AppDataSource } from "../database";
import { Task } from "../entities/Task";
import { Column } from "../entities/Column";

export class TaskController {
  static async createTask(req: Request, res: Response) {
    const { title, description, columnId } = req.body;

    try {
      const taskRepository = AppDataSource.getRepository(Task);
      const columnRepository = AppDataSource.getRepository(Column);
      const column = await columnRepository.findOneBy({ id: columnId });

      if (!column) {
        return res.status(404).json({ message: "Column not found" });
      }

      const task = new Task();
      task.title = title;
      task.description = description;
      task.column = column;
      await taskRepository.save(task);

      res.status(201).json({ message: "Task created successfully", task });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async getTasks(req: Request, res: Response) {
    const columnId = req.params.columnId;

    try {
      const taskRepository = AppDataSource.getRepository(Task);
      const tasks = await taskRepository.find({ where: { column: { id: columnId } } });
      res.status(200).json(tasks);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}
