import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany } from "typeorm";
import { User } from "./User";
import { Column as KanbanColumn } from "./Column";

@Entity()
export class Board {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @ManyToOne(() => User, (user) => user.boards, { onDelete: "CASCADE" })
  user: User;

  @OneToMany(() => KanbanColumn, (column) => column.board)
  columns: KanbanColumn[];
}
