import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany } from "typeorm";
import { Board } from "./Board";
import { Task } from "./Task"; 

@Entity()
export class KanbanColumn {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @ManyToOne(() => Board, (board) => board.columns, { onDelete: "CASCADE" })
  board: Board;

  @OneToMany(() => Task, (task) => task.column)
  tasks: Task[];  
}

export { Column };
