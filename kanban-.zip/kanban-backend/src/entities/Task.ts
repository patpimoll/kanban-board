import { Entity, PrimaryGeneratedColumn, Column as TypeORMColumn, ManyToOne } from "typeorm";
import { KanbanColumn } from "./Column";  

@Entity()
export class Task {
  [x: string]: any;
  task: any;
  [x: string]: any;
  @PrimaryGeneratedColumn()
  id: number;

  @TypeORMColumn()  
  title: string;

  @TypeORMColumn({ nullable: true })
  description: string;

  @ManyToOne(() => KanbanColumn, (column) => column.tasks, { onDelete: "CASCADE" })
  column: KanbanColumn;
}
