import { Router } from "express";
import { BoardController } from "../controllers/BoardController";

const router = Router();

router.post("/create", BoardController.createBoard);
router.get("/", BoardController.getBoards);

export default router;
