import { Router } from "express";
import { ColumnController } from "../controllers/ColumnController";

const router = Router();

router.post("/create", ColumnController.createColumn);
router.get("/:boardId", ColumnController.getColumns);

export default router;
