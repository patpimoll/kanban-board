import { Router } from "express";
import { TaskController } from "../controllers/TaskController";

const router = Router();

router.post("/create", TaskController.createTask);
router.get("/:columnId", TaskController.getTasks);

export default router;
