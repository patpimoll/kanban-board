import "reflect-metadata";
import { AppDataSource } from "./database";
import app from "./app";

const PORT = 3000;

AppDataSource.initialize()
  .then(() => {
    console.log("Database connected");
    app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
  })
  .catch((error) => console.log("Error connecting to database:", error));

