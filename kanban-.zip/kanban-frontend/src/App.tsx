import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import BoardPage from "./pages/BoardPage";
import Login from "./pages/login";
import Register from "./pages/Register";

const App: React.FC = () => {
  return (
    <Router>
      <div>
        <h1>Kanban Board</h1>
        <Routes>
          <Route path="/" element={<BoardPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
