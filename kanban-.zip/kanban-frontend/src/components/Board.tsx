import React, { useState, useEffect } from "react";
import { BoardService } from "../services/BoardService";
import Column from "./Column";
import ColumnForm from "./ColumnForm";

interface ColumnType {
  id: number;
  name: string;
}

const Board: React.FC = () => {
  const [columns, setColumns] = useState<ColumnType[]>([]);
  const [boardName, setBoardName] = useState("Kanban Board");
  const [boardId, setBoardId] = useState<string>("1"); // สมมติว่า boardId เป็น "1" คุณอาจจะต้องปรับให้เหมาะสม

  useEffect(() => {
    const fetchColumns = async () => {
      try {
        const response = await BoardService.getColumns(boardId);
        setColumns(response.data);
      } catch (error) {
        console.error("Failed to fetch columns:", error);
      }
    };

    fetchColumns();
  }, [boardId]);

  const handleAddColumn = (columnName: string) => {
    setColumns((prevColumns) => [...prevColumns, { id: Date.now(), name: columnName }]);
  };

  return (
    <div>
      <h1>{boardName}</h1>
      <ColumnForm boardId={boardId} onAddColumn={handleAddColumn} />
      <div className="columns-container">
        {columns.map((column) => (
          <Column key={column.id} boardId={boardId} />
        ))}
      </div>
    </div>
  );
};

export default Board;
