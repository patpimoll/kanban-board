import React, { useState, useEffect } from "react";
import { ColumnService } from "../services/ColumnService";
import { TaskService } from "../services/TaskService";

interface ColumnProps {
  boardId: string;
}

const Column: React.FC<ColumnProps> = ({ boardId }) => {
  const [columns, setColumns] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [tasksByColumn, setTasksByColumn] = useState<any>({}); // ใช้ object เก็บ tasks แยกตาม columnId

  useEffect(() => {
    const fetchColumns = async () => {
      const data = await ColumnService.getColumns(boardId);
      setColumns(data);
    };

    fetchColumns();
  }, [boardId]);

  const fetchTasks = async (columnId: string) => {
    const data = await TaskService.getTasks(columnId);
    setTasksByColumn((prevTasks) => ({
      ...prevTasks,
      [columnId]: data, 
    }));
  };

  return (
    <div>
      {columns.map((column) => (
        <div key={column.id}>
          <h2>{column.name}</h2>
          <button onClick={() => fetchTasks(column.id)}>Show Tasks</button>
          <ul>
            {/* แสดง tasks ที่เก็บแยกตาม columnId */}
            {tasksByColumn[column.id]?.map((task: any) => (
              <li key={task.id}>{task.title}</li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default Column;
