import React, { useState } from "react";
import { ColumnService } from "../services/ColumnService";

interface ColumnFormProps {
  boardId: string; 
  onAddColumn: (columnName: string) => void;
}

const ColumnForm: React.FC<ColumnFormProps> = ({ boardId, onAddColumn }) => {
  const [columnName, setColumnName] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (columnName.trim() === "") {
      setErrorMessage("Column name is required.");
      return;
    }

    try {
      
      const newColumn = await ColumnService.createColumn(columnName, boardId);
      onAddColumn(newColumn.name); 
      setColumnName(""); 
      setErrorMessage(""); 
    } catch (error) {
      setErrorMessage("Error creating column. Please try again.");
    }
  };

  return (
    <div>
      <h3>Create a new column</h3>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Column Name"
          value={columnName}
          onChange={(e) => setColumnName(e.target.value)}
        />
        <button type="submit">Create Column</button>
      </form>
      {errorMessage && <p style={{ color: "red" }}>{errorMessage}</p>}
    </div>
  );
};

export default ColumnForm;
