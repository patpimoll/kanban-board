import React from "react";

const Task: React.FC<{ task: any }> = ({ task }) => {
  return (
    <div className="task">
      <h3>{task.name}</h3>
      <p>Assigned to: {task.assignee}</p>
      <p>{task.description}</p>
    </div>
  );
};

export default Task;
