import React, { useState, useEffect } from "react";
import { BoardService } from "../services/BoardService";
import ColumnForm from "../components/ColumnForm";
import Column from "../components/Column";

const BoardPage: React.FC = () => {
  const [boards, setBoards] = useState([]);

  useEffect(() => {
    const fetchBoards = async () => {
      const data = await BoardService.getBoards();
      setBoards(data);
    };

    fetchBoards();
  }, []);

  return (
    <div>
      <h1>Boards</h1>
      <ul>
        {boards.map((board: any) => (
          <li key={board.id}>
            <h2>{board.name}</h2>
            <ColumnForm boardId={board.id} />
            <Column boardId={board.id} />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BoardPage;
