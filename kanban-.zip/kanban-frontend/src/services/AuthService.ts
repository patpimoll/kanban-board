import axios from "axios";

const API_URL = "http://localhost:3000/api/auth";

export const AuthService = {
  register: (email: string, password: string) => {
    return axios.post(`${API_URL}/register`, { email, password });
  },
  login: (email: string, password: string) => {
    return axios.post(`${API_URL}/login`, { email, password });
  },
};
