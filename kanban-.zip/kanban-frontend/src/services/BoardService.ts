import axios from 'axios';

const API_URL = "http://localhost:3000/api/boards";

export const BoardService = {
  getBoards: async () => {
    try {
      const response = await axios.get(API_URL);
      return response.data;  
    } catch (error) {
      throw new Error("Failed to fetch boards");
    }
  },
  
  getColumns: async (boardId: string) => {
    try {
      const response = await axios.get(`${API_URL}/columns`);
      return response.data;  
    } catch (error) {
      throw new Error("Failed to fetch columns");
    }
  },

  addColumn: async (columnName: string) => {
    try {
      const response = await axios.post(`${API_URL}/columns`, { name: columnName });
      return response.data;  
    } catch (error) {
      throw new Error("Failed to add column");
    }
  }
};
