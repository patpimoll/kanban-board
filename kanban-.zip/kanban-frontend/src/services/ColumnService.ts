import axios from "axios";

const API_URL = "http://localhost:3000/api/columns";

export const ColumnService = {

  getColumns: async (boardId: string) => {
    const response = await axios.get(`${API_URL}/board/${boardId}`);
    return response.data;
  },
  
  createColumn: async (name: string, boardId: string) => {
    const response = await axios.post(`${API_URL}/create`, { name, boardId });
    return response.data;
  },
};
