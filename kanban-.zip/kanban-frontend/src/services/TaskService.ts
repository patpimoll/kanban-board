import axios from "axios";

const API_URL = "http://localhost:3000/api/tasks";

export const TaskService = {
  getTasks: async (columnId: string) => {
    const response = await axios.get(`${API_URL}/${columnId}`);
    return response.data;
  },
  createTask: async (title: string, description: string, columnId: string) => {
    const response = await axios.post(`${API_URL}/create`, { title, description, columnId });
    return response.data;
  },
};
